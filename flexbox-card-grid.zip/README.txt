A Pen created at CodePen.io. You can find this one at http://codepen.io/mcraiganthony/pen/NxGxqm.

 Quick prototype of equal height cards using flexbox grid layout. Also demonstrates the use of CSS aspect ratios (check out the images) and CSS filters.